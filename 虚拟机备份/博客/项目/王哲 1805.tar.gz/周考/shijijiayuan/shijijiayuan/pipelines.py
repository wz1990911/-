# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

import pymongo
class ShijijiayuanPipeline(object):
    def process_item(self, item, spider):
        """
            将数据保存到数据库(mongodb)
            """

        def __init__(self, host, port, db):
            # 在初始化方法中创建数据库连接
            self.client = pymongo.MongoClient(host, port)
            # 获取数据库
            self.db = self.client[db]

        @classmethod
        def from_crawler(cls, crawler):

            host = crawler.settings['MONGO_HOST']
            port = crawler.settings['MONGO_PORT']
            db = crawler.settings['MONGO_DB']
            return cls(host, port, db)

        def process_item(self, item, spider):

            try:
                col_name = self.db['shijijiayuan']
                col_name.insert(dict(item))
            except Exception as err:
                print('插入失败')
                print(err)

            return item

        def close_spider(self, spider):

            self.client.close()
        return item
