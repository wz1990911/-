from django.apps import AppConfig


class XiaoshuoConfig(AppConfig):
    name = 'xiaoshuo'
